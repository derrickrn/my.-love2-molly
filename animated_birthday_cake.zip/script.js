
document.getElementById("message").textContent = "Happy Birthday to You!";
